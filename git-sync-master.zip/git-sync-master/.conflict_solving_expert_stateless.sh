

# https://gist.github.com/briceburg/3f41f09bdc478d21bcf8
# git merge-base --is-ancestor A B

# https://stackoverflow.com/questions/24504400/whats-the-correct-way-to-check-if-its-possible-to-perform-a-fast-forward-merge/31500335#31500335
# git rev-list --max-count 1 $local_branch..$remote_branch

# https://git-scm.com/docs/git-rev-list

# https://git-scm.com/docs/git-rev-parse

# Workflow
## Short
## Long
### Methos


